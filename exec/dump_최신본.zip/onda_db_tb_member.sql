-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_member`
--

DROP TABLE IF EXISTS `tb_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_member` (
  `member_seq` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `member_id` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`member_seq`),
  UNIQUE KEY `UK_2corc7ojj2bob4ix9ny5gr826` (`email`),
  UNIQUE KEY `UK_dmuwamnfbfrp6ec8vl1jgyuul` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_member`
--

LOCK TABLES `tb_member` WRITE;
/*!40000 ALTER TABLE `tb_member` DISABLE KEYS */;
INSERT INTO `tb_member` VALUES (1,'test01@onda.com','test01','테스트222','$2a$10$xCmCuHtVqYwTeO7lYqdYiulr.tY3dDbZCtKmDJQw.zvzyn8dmtgFK'),(2,'test02@onda.com','test02','테스트','$2a$10$D6QUTi4ypm0cfLTVXT7QNOjFn2k3rVYZG20f1nVvjRhFK4e0YwT0y'),(3,'test03@onda.com','test03','asdfqwrasd','$2a$10$dN0GOK5Pip7R0j6Aap.Avejg.0EmEWZwQ7IPUlygccICka5MUVsMG'),(4,'test04@onda.com','test04','닉네임변경','$2a$10$lzCvMkiq0ZO2Xqbp3jgbSOEP.x7RqBKIX1Hhg1T1DiWzmn6YZsUI.'),(6,'onda01@onda.com','onda01','온다다','$2a$10$Nxe2WF8ZnPq9uh8aGgon6.xQ.q3851FPyiubdvLbwB/NqmYnPdvQy'),(10,'onda1@onda.com','onda1','온다aa','$2a$10$H2vC3UZkpQYOyW/kZ3XB/OSi3xRimzGNtRI5SqmOV/WrKMUcrE6cm'),(11,'0xe82de@gmail.com','hello','hello','$2a$10$.xzlLD8uDk89/upuXGjXSOY6rW7StwKL5gTQLdSNBAkuPr8AnKvDK'),(12,'onda2@onda.com','onda2','온다2','$2a$10$a5BaqThcA8zG3ORkVYb9ZuwvbdbJ771Kk18l8jgWxdL6TKY/DSnW6');
/*!40000 ALTER TABLE `tb_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:36:49
