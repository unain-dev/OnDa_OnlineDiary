-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_text`
--

DROP TABLE IF EXISTS `tb_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_text` (
  `text_seq` bigint NOT NULL AUTO_INCREMENT,
  `content` longtext NOT NULL,
  `header` varchar(255) NOT NULL,
  `height` bigint NOT NULL,
  `width` bigint NOT NULL,
  `x` bigint NOT NULL,
  `y` bigint NOT NULL,
  `diary_seq` bigint NOT NULL,
  PRIMARY KEY (`text_seq`),
  KEY `FKh3u1k4vh0trd74agu1uvi7be4` (`diary_seq`),
  CONSTRAINT `FKh3u1k4vh0trd74agu1uvi7be4` FOREIGN KEY (`diary_seq`) REFERENCES `tb_diary` (`diary_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_text`
--

LOCK TABLES `tb_text` WRITE;
/*!40000 ALTER TABLE `tb_text` DISABLE KEYS */;
INSERT INTO `tb_text` VALUES (19,'<p>내용ㅁㄴㅇㄹ</p>','제목ㅁㄴㅇㄹ',200,200,112,56,8),(20,'내용','제목',200,200,404,46,8),(21,'내용','제목',200,200,660,354,8),(22,'<p>내용아마도</p>','제목조건찾기',200,200,100,200,8),(33,'<p>내용</p>','제목',200,200,459,2,29),(34,'내용','제목',200,200,632,328,21),(48,'<p>내용adawdwad</p>','제목',200,200,1003,259,38),(51,'<p>ㅁㄴㅇㄻㄴㅇ</p>','제목',200,200,100,200,43),(52,'<h1><span style=\"color: rgb(235, 214, 255);\">뚜이뚜이</span></h1>','제목',200,200,293,88,43),(53,'내용','제목',200,200,100,200,44),(58,'<p>라이브 강의</p><p>- 알아두면 쓸모 있는 데이터베이스 객체</p>','제목',86,322,100,200,46),(62,'<p><br></p><p><br></p><p>모바일 앱, 어떤 프레임워크로 개발할까?</p>','라이브 강의',163,228,289,117,50),(63,'<p>엔터 안누르고 체크</p>','제목',200,200,394,37,14),(64,'<p>엔터 누르고 체크</p>','제목',200,200,1084,174,14),(72,'<p>빙수는 팥빙수지!</p>','',92,173,603,218,59),(77,'<p><br></p><p>등록금 0원...</p><p>몬스타엑스....메...모</p>','싸피데이 참여',114,209,446,159,60),(86,'<p>캐싱의 개념과 적용</p>','라이브 강의',200,200,1068,173,63),(87,'<p><br></p><p>플러터로 앱 개발해보기</p>','라이브 강의',200,200,628,199,56),(88,'<p>프로젝트 산출물 작성 및 제출</p><p>5/23 ~ 5/30</p>','포트폴리오 위크',131,278,507,177,64),(89,'<p>교보재 인강 마감</p>','',82,178,1000,25,61),(90,'<p><br></p><p>포트폴리오 발표 및 F/B</p>','포트폴리오 위크',87,248,983,194,61),(91,'<p>SSAFY GIT에 5/30(월) 17시까지 제출</p><p><br></p><p>공지사항 URL</p><p><span class=\"ql-font-serif\">https://edu.ssafy.com/edu/board/notice/detail.do?searchBrdItmCdVal=&amp;brdItmSeq=39386&amp;searchWord=&amp;_csrf=4bb68770-cff0-4258-a9cd-3694b8b03046&amp;pageIndex=1</span></p>','포트폴리오 위크',239,324,1035,185,65),(92,'<p>추천도서[주니어 개발자 성장 촉진제] - 이승윤 컨설턴트님</p>','라이브 강의',106,295,942,119,66),(93,'<p>IT Trend</p>','라이브 강의',73,174,726,142,67),(94,'<p>취업특강 16:00 ~ 18:00</p><p>=&gt; 입퇴실 설문 꼭 하기!</p>','5월',99,226,653,117,51),(115,'<h3><span style=\"color: rgb(230, 0, 0);\">20일 금요일</span>까지 프로젝트 활용 동의서 제출</h3>','',131,433,1163,27,55),(116,'<p><br></p><p>-프로젝트 산출물 등록: 5월 20일(금) 12시 이전까지</p><p>-최종평가 : 5월 20일(금) 13시~17시 *평가연장불가</p><p>-포트폴리오위크 : 5월 23(월)~30일(월)</p><p>-UCC 산출물 등록 : 5월 24일(화) 24시 이전까지</p><p>-본선발표회 : 5월 25일(수)~26일(목), webex</p><p>-결선발표회 : 5월 31일(화), 서울캠퍼스(역삼)</p><p>상기 일정은 코로나19 상황 등에 따라 변동 가능성 있습니다.</p>','5월 학사일정',232,406,574,253,55),(117,'<p>최종평가! 13:00 ~ 17:00</p>','자율PJT',104,200,162,117,55),(118,'<p><em style=\"color: rgb(153, 51, 255);\"><s>내일 맛있는거 먹기!!</s></em></p>','토욜플랜!!!!',77,298,1265,338,55),(119,'<p>정규표현식</p>','라이브 강의',200,200,696,194,68),(122,'<p>타코야끼 맛있어</p>','',109,165,597,248,57),(123,'<p>코드 리팩토링</p>','라이브 강의',200,200,894,356,57),(124,'<p>프로젝트 발표 Tip</p>','라이브 강의',95,265,383,253,48),(125,'<p>출석췤 ?</p>','입퇴실',74,115,656,209,48),(126,'<p><br></p>','어린이날',55,121,226,145,52),(129,'<p>프로젝트 발표 Tip</p>','라이브 강의',84,195,100,200,49),(130,'<p>UCC 영상재촬영</p>','프로젝트 마무으리',200,200,334,169,49),(132,'<p>내용</p>','제목',200,200,104,200,70),(133,'<p>내용</p>','제목',200,200,100,200,71),(134,'<p>내용</p>','제목',200,200,100,200,72),(138,'<p>내용</p>','제목',200,200,100,200,69),(139,'<p>내용</p>','제목',200,200,100,200,73),(140,'<p>내용</p>','라이브강의',200,200,100,200,74),(141,'<p>내용</p>','제목',200,200,100,200,75),(142,'<p>내용</p>','제목',200,200,624,121,75),(143,'<p>내용</p>','제목',200,200,1322,129,76),(145,'<p>오늘도 코딩하느라 너무 힘들었다...</p>','오늘의 일기',200,382,406,54,31),(146,'<p>오늘은 뭐하징?</p>','뭐하징',200,200,286,162,24),(147,'<p>우왕</p>','이게 뭐양',200,200,117,76,25),(149,'<p>할일이 너어무 많아</p>','너무 바쁘다',200,200,629,104,28),(155,'<p>그렇지만 난 코딩을 한다...</p>','날씨가 너무 좋다....',91,230,48,28,1),(156,'<h1><strong class=\"ql-font-serif\" style=\"color: rgb(161, 0, 0);\"><u>7팀 온다 파이팅!!!!!!!!!!!!</u></strong></h1>','프로젝트 발표날!!!!!',125,425,552,177,62),(160,'<p>오늘은 숙제가 없었다</p><p>그래서 좋았다</p>','오늘의 일기',243,253,633,7,15),(161,'<p>발표 너무 떨리네요ㅠㅠ</p>','발표ㅠㅠ',161,347,486,102,81);
/*!40000 ALTER TABLE `tb_text` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:37:07
