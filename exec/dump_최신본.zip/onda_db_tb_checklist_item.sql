-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_checklist_item`
--

DROP TABLE IF EXISTS `tb_checklist_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_checklist_item` (
  `checklist_item_seq` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `is_checked` bit(1) NOT NULL,
  `checklist_seq` bigint NOT NULL,
  PRIMARY KEY (`checklist_item_seq`),
  KEY `FKccjqjoflpsfbv6181xv0s8v50` (`checklist_seq`),
  CONSTRAINT `FKccjqjoflpsfbv6181xv0s8v50` FOREIGN KEY (`checklist_seq`) REFERENCES `tb_checklist` (`checklist_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_checklist_item`
--

LOCK TABLES `tb_checklist_item` WRITE;
/*!40000 ALTER TABLE `tb_checklist_item` DISABLE KEYS */;
INSERT INTO `tb_checklist_item` VALUES (5,'s',_binary '\0',2),(16,'ㅁㄴㅇㄹ',_binary '\0',14),(21,'asdf',_binary '\0',19),(37,'ㄹㄹㄹ',_binary '\0',31),(73,'프로젝트 최종 발표',_binary '\0',42),(74,'산출물 제출',_binary '\0',42),(75,'프로젝트 회고, 정리',_binary '\0',42),(76,'자율PJT 최종평가',_binary '\0',42),(77,'책상 정리하기',_binary '',43),(78,'회비 보내기',_binary '',43),(79,'스트레칭',_binary '\0',43),(80,'어린이날 선물',_binary '\0',44),(81,'어버이날 선물',_binary '\0',44),(83,'첵첵',_binary '\0',49),(84,'ㅇㅁㄹ',_binary '\0',50),(89,'장보기',_binary '\0',53),(90,'코딩하기',_binary '\0',53),(91,'고양이 밥 주기',_binary '\0',53),(92,'x',_binary '\0',54),(99,'CSS 고치기',_binary '',58),(100,'UCC 제작하기',_binary '\0',58),(105,'숙제',_binary '\0',61),(106,'방청소하기',_binary '\0',61),(107,'놀기',_binary '\0',61),(108,'쇼핑',_binary '\0',62);
/*!40000 ALTER TABLE `tb_checklist_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:36:44
