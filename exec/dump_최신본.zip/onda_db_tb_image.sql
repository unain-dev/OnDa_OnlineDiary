-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_image`
--

DROP TABLE IF EXISTS `tb_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_image` (
  `image_seq` bigint NOT NULL AUTO_INCREMENT,
  `encoded_name` varchar(255) NOT NULL,
  `origin_name` varchar(255) NOT NULL,
  `saved_path` varchar(255) NOT NULL,
  `height` bigint NOT NULL,
  `width` bigint NOT NULL,
  `x` bigint NOT NULL,
  `y` bigint NOT NULL,
  `diary_seq` bigint NOT NULL,
  PRIMARY KEY (`image_seq`),
  KEY `FKp34b4ksrt94qt10upje0knhja` (`diary_seq`),
  CONSTRAINT `FKp34b4ksrt94qt10upje0knhja` FOREIGN KEY (`diary_seq`) REFERENCES `tb_diary` (`diary_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_image`
--

LOCK TABLES `tb_image` WRITE;
/*!40000 ALTER TABLE `tb_image` DISABLE KEYS */;
INSERT INTO `tb_image` VALUES (1,'3ed56341-b6f9-488e-83fa-1020f259e456.png','filled_star.png','images/2022-05-17',200,200,236,2,20),(3,'118f8c20-1d4c-4f3d-9eb9-c622c1756d85.jpeg','KakaoTalk_20220511_200654286_01.jpeg','images/2022-05-17',200,200,766,90,21),(6,'2bf9b748-17b4-4758-95ed-0c329aa88456.jpeg','i14974423299.jpeg','images/2022-05-17',140,130,649,91,15),(7,'77f38580-4a35-44c2-895c-a12c3cf01a25.png','filled_star.png','images/2022-05-17',200,200,206,43,27),(8,'e1fddf51-9418-4f97-936c-040bcad80f4f.png','filled_star.png','images/2022-05-17',200,200,274,51,23),(9,'b8f61f5f-5afe-41dc-9ed1-421978e29ef7.jpeg','KakaoTalk_20220511_200654286_01.jpeg','images/2022-05-17',200,200,355,275,29),(10,'84690fdf-60a3-435d-b9fb-1b2dea6434b6.png','서울_1반_안지애.png','images/2022-05-18',413,475,790,11,43),(13,'d19f2d40-e571-4c7c-ab16-9e8382f33dc3.png','온  다.png','images/2022-05-18',200,200,752,11,39),(15,'3a45f72a-973b-479d-953f-31489a7aea0e.PNG','타코야끼.PNG','images/2022-05-18',303,248,332,105,57),(16,'b93a3802-2382-45eb-886f-35bd207dbf3e.png','SSAFY.png','images/2022-05-18',248,434,403,10,55),(17,'ce4df9ae-e21a-408f-b04c-ef146f7c8ce1.png','얘느 누구지.png','images/2022-05-19',200,200,658,138,31),(18,'fa1f2ab2-aed6-46b6-adf0-ed6bd5587032.png','온  다.png','images/2022-05-19',200,200,879,4,47),(21,'e3cfe9e3-f8d1-4660-8bee-0e64dd109a98.png','KakaoTalk_20220519_125034137_01.png','images/2022-05-19',328,485,514,76,1),(23,'9f3d0d0d-139f-4e29-99f9-4b3a4e477c0e.png','얘느 누구지.png','images/2022-05-19',200,200,1027,229,81);
/*!40000 ALTER TABLE `tb_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:37:02
