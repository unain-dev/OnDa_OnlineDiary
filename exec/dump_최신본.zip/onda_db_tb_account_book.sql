-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_account_book`
--

DROP TABLE IF EXISTS `tb_account_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_account_book` (
  `account_book_seq` bigint NOT NULL AUTO_INCREMENT,
  `height` bigint NOT NULL,
  `width` bigint NOT NULL,
  `x` bigint NOT NULL,
  `y` bigint NOT NULL,
  `diary_seq` bigint NOT NULL,
  PRIMARY KEY (`account_book_seq`),
  KEY `FK4gn39obqywll7fp7tomm5e4w4` (`diary_seq`),
  CONSTRAINT `FK4gn39obqywll7fp7tomm5e4w4` FOREIGN KEY (`diary_seq`) REFERENCES `tb_diary` (`diary_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_account_book`
--

LOCK TABLES `tb_account_book` WRITE;
/*!40000 ALTER TABLE `tb_account_book` DISABLE KEYS */;
INSERT INTO `tb_account_book` VALUES (10,200,200,656,109,8),(26,200,200,61,108,29),(27,200,317,223,362,21),(35,234,435,453,180,43),(44,111,340,371,358,46),(49,170,306,956,74,58),(50,138,446,739,96,59),(58,200,200,56,17,23),(59,150,507,890,90,56),(60,157,460,788,262,51),(63,114,522,758,81,57),(64,151,394,859,163,48),(65,200,431,424,61,47),(67,200,372,147,33,39),(71,144,385,42,141,1),(73,200,406,547,237,81);
/*!40000 ALTER TABLE `tb_account_book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:37:04
