-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_checklist`
--

DROP TABLE IF EXISTS `tb_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_checklist` (
  `checklist_seq` bigint NOT NULL AUTO_INCREMENT,
  `checklist_header` varchar(255) NOT NULL,
  `height` bigint NOT NULL,
  `width` bigint NOT NULL,
  `x` bigint NOT NULL,
  `y` bigint NOT NULL,
  `diary_seq` bigint NOT NULL,
  PRIMARY KEY (`checklist_seq`),
  KEY `FKqbrsyig9cva9rox82xtr540ar` (`diary_seq`),
  CONSTRAINT `FKqbrsyig9cva9rox82xtr540ar` FOREIGN KEY (`diary_seq`) REFERENCES `tb_diary` (`diary_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_checklist`
--

LOCK TABLES `tb_checklist` WRITE;
/*!40000 ALTER TABLE `tb_checklist` DISABLE KEYS */;
INSERT INTO `tb_checklist` VALUES (2,'dsfa',200,200,664,58,3),(14,'ㅁㄴㅇㄹ',200,200,354,311,8),(19,'asdf',200,200,762,204,29),(31,'ㄹㄹㄹ',200,200,100,200,14),(42,'체크리스트',200,201,943,105,55),(43,'TO DO',146,236,677,383,48),(44,'체크리스트',115,230,517,109,52),(49,'',200,200,747,43,69),(50,'',200,200,1045,160,69),(53,'오늘 해야할 일',200,353,266,86,77),(54,'x',200,200,429,26,28),(58,'할일',114,189,1164,15,1),(61,'할일',134,265,175,119,15),(62,'오늘의 할일',200,200,922,91,81);
/*!40000 ALTER TABLE `tb_checklist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:36:52
