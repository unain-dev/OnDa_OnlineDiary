-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: onda_db
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_account_book_item`
--

DROP TABLE IF EXISTS `tb_account_book_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_account_book_item` (
  `account_book_item_seq` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  `income` varchar(255) NOT NULL,
  `outcome` varchar(255) NOT NULL,
  `account_book_seq` bigint NOT NULL,
  PRIMARY KEY (`account_book_item_seq`),
  KEY `FKd9db8s6tdxc1y8w9s39l4jxuk` (`account_book_seq`),
  CONSTRAINT `FKd9db8s6tdxc1y8w9s39l4jxuk` FOREIGN KEY (`account_book_seq`) REFERENCES `tb_account_book` (`account_book_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_account_book_item`
--

LOCK TABLES `tb_account_book_item` WRITE;
/*!40000 ALTER TABLE `tb_account_book_item` DISABLE KEYS */;
INSERT INTO `tb_account_book_item` VALUES (8,'ㅁㄴㅇㄹ','12','',10),(23,'fff','123','123',26),(24,'ㅁㄴㅇㄹ','12','',27),(26,'홈런볼 사먹음','','1500',35),(42,'홈런볼 사먹음','','1500',44),(48,'응떡 중상맛','','21000',49),(49,'팥인절미 설빙','','9900',50),(60,'1000','123','123',58),(61,'애플망고치즈설빙','','12900',59),(62,'SSAFY 교육지원금','1000000','',60),(63,'통신비','','90830',60),(66,'타코야끼 두개!','','15000',63),(67,'붕어싸만코','','1000',64),(68,'회비','','20000',64),(69,'고양이 밥','','30000',65),(71,'월급','100','',67),(78,'스타벅스 커피','','6000',71),(79,'떡볶이','','4000',71),(82,'고양이 장난감','','1000',73),(83,'월급','10000','',73);
/*!40000 ALTER TABLE `tb_account_book_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-19 15:36:59
